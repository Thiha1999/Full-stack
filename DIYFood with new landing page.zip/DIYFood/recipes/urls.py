from django.contrib import admin
from django.urls import path
from .views import CreateRecipe, DetailRecipe, UpdateRecipe, SearchRecipe

urlpatterns = [
    path('create/', CreateRecipe.as_view(), name='recipe-create'),
    path('<int:pk>/', DetailRecipe.as_view(), name='recipe-detail'),
    path('<int:pk>/update', UpdateRecipe.as_view(), name='recipe-update'),
    path('search/', SearchRecipe.as_view(), name='recipe-search'),
]   