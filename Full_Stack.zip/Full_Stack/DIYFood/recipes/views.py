import imp
from msilib.schema import Class
from multiprocessing import context
from pyexpat import model
from re import template
from turtle import title
from django.shortcuts import render, reverse
from django.db.models import Q
from django.views import View
from django.views.generic.edit import CreateView, UpdateView
from django.views.generic.detail import DetailView
from django.views.generic.list import ListView
from .models import Recipe

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

class Index(ListView):
    model = Recipe
    templat_name = 'recipes/index.html'
    order_by = '-date_posted'

class CreateRecipe(LoginRequiredMixin, CreateView):
    model = Recipe
    fields = ['title', 'ingredients', 'description', 'steps', 'thumbnail']
    template_name = 'recipes/create_recipe.html'

    def form_valid(self, form):
        form.instance.uploader = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('recipe-detail', kwargs={'pk': self.object.pk})

class DetailRecipe(DetailView):
    model = Recipe
    template_name = 'recipes/detail_recipe.html'

class UpdateRecipe(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Recipe
    fields = ['title', 'ingredients', 'description', 'steps', 'thumbnail']
    template_name = 'recipes/create_recipe.html'

    def get_success_url(self):
        return reverse('recipe-detail', kwargs={'pk': self.object.pk})

    def test_func(self):
        recipe = self.get_object()
        return self.request.user == recipe.uploader


class SearchRecipe(View):
    def get(self, request, *args, **kwargs):
        query = self.request.GET.get("q")

        query_list = Recipe.objects.filter(
            Q(title__icontains=query) |
            Q(uploader__username__icontains=query) |
            Q(description__icontains=query) |
            Q(ingredients__icontains=query)
        )

        context = {
            'query_list': query_list,
        }

        return render(request,'recipes/search.html', context)