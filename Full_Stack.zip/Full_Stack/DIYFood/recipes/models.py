from tkinter.ttk import setup_master
from turtle import title
from django.db import models
from django.utils import timezone
from django.core.validators import FileExtensionValidator
from django.contrib.auth.models import User

class Recipe(models.Model):
    uploader = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    ingredients = models.TextField()
    description = models.TextField()
    steps = models.TextField()
    thumbnail = models.FileField(upload_to='uploads/thumbnails', validators= [FileExtensionValidator(allowed_extensions=['png','jpg', 'jpeg'])])
    date_posted = models.DateTimeField(default=timezone.now)